# frozen_string_literal: true

module Memoist
  VERSION = '1.0.0'
end
