# frozen_string_literal: true

require_relative 'sys/uname'
