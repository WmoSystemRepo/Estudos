# Contributors

- Austin Ziegler (@halostatue) created diff-lcs.

Thanks to everyone else who has contributed to diff-lcs over the years:

- @ginriki
- @joshbronson
- @kevinmook
- @mckaz
- Akinori Musha
- Artem Ignatyev
- Brandon Fish
- Baptiste Courtois (@annih)
- Camille Drapier
- Cédric Boutillier
- @earlopain
- Gregg Kellogg
- Jagdeep Singh
- Jason Gladish
- Jon Rowe
- Josef Strzibny
- Josep (@apuratepp)
- Josh Bronson
- Jun Aruga
- Justin Steele
- Kenichi Kamiya
- Kensuke Nagae
- Kevin Ansfield
- Koichi Ito
- Mark Friedgan
- Masato Nakamura
- Mark Young
- Michael Granger
- Myron Marston
- Nicolas Leger
- Oleg Orlov
- Patrick Linnane
- Paul Kunysch
- Pete Higgins
- Peter Goldstein
- Peter Wagenet
- Philippe Lafoucrière
- Ryan Lovelett
- Scott Steele
- Simon Courtois
- Tien (@tiendo1011)
- Tomas Jura
- Vít Ondruch
