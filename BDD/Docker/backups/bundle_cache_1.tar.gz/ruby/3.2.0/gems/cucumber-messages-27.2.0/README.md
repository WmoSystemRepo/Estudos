# Cucumber Messages for Ruby (JSON schema)

See main [README](../README.md)
