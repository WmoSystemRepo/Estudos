# frozen_string_literal: true

require_relative 'id_generator/uuid'
require_relative 'id_generator/incrementing'
