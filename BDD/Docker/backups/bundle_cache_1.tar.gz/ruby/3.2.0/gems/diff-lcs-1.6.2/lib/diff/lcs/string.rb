# frozen_string_literal: true

class String
  include Diff::LCS
end
