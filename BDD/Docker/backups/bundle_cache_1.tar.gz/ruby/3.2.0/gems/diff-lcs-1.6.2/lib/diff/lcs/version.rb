# frozen_string_literal: true

module Diff
  module LCS
    VERSION = "1.6.2"
  end
end
