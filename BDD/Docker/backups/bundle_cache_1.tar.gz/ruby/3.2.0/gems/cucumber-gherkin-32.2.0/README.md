# Gherkin for Ruby

Gherkin parser/compiler for Ruby. Please see [Gherkin](https://github.com/cucumber/gherkin) for details.

## To build

```bash
cd <project_root>/ruby
make
```
